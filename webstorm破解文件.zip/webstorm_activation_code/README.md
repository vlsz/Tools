# webStorm激活码

#### 介绍
webStorm2019，2020激活码，永久激活
#### 使用说明

此教程适用于jetbrains 的所有系列的软件
gitee: 
永久激活(以win为例/mac方法一样)
1. 下载jar包https://gitee.com/rdsunday/webstorm_activation_code/blob/master/jetbrains-agent.jar
2. 以webstorm2019为例
3. 先下载后得到jetbrains-agent.jar，把它放到你认为合适的文件夹内。
启动你的IDE，如果上来就需要注册，选择：试用（Evaluate for free）进入IDE 
![在这里插入图片描述](https://img-blog.csdnimg.cn/2020070110063438.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3dlaXhpbl80Mzc1NTEwNA==,size_16,color_FFFFFF,t_70)
4. 拖动jar 到编辑器里面 
![在这里插入图片描述](https://img-blog.csdnimg.cn/20200701100647347.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3dlaXhpbl80Mzc1NTEwNA==,size_16,color_FFFFFF,t_70)
5. 选择resart 
![在这里插入图片描述](https://img-blog.csdnimg.cn/20200701100705389.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3dlaXhpbl80Mzc1NTEwNA==,size_16,color_FFFFFF,t_70)
6. 点击离线激活  
![在这里插入图片描述](https://img-blog.csdnimg.cn/20200701100714719.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3dlaXhpbl80Mzc1NTEwNA==,size_16,color_FFFFFF,t_70)
![在这里插入图片描述](https://img-blog.csdnimg.cn/20200701100730131.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3dlaXhpbl80Mzc1NTEwNA==,size_16,color_FFFFFF,t_70)
7 . 激活成功 
![在这里插入图片描述](https://img-blog.csdnimg.cn/20200701100739959.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3dlaXhpbl80Mzc1NTEwNA==,size_16,color_FFFFFF,t_70)